from flask import Flask, render_template_string, request

app = Flask(__name__)

HTML = """
<!doctype html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Hello World Spiegel</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 700px;
            margin: 40px auto;
            padding: 0 20px;
            line-height: 1.5;
        }
        h1 {
            margin-bottom: 24px;
        }
        form {
            margin-bottom: 24px;
        }
        input[type="text"] {
            width: 100%;\n            max-width: 400px;
            padding: 10px;
            font-size: 16px;
        }
        button {
            margin-top: 12px;
            padding: 10px 16px;
            font-size: 16px;
            cursor: pointer;
        }
        .result {
            margin-top: 20px;
            padding: 16px;
            background: #f4f4f4;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <h1>Hello World. Dit is debeste release.</h1>

    <form method="post">
        <label for="tekst">Typ iets:</label><br>
        <input type="text" id="tekst" name="tekst" value="{{ tekst }}" placeholder="Voer tekst in">
        <br>
        <button type="submit">Toon in spiegelbeeld ...</button>
    </form>

    {% if gespiegeld is not none %}
    <div class="result">
        <strong>Spiegelbeeld:</strong>
        <p>{{ gespiegeld }}</p>
    </div>
    {% endif %}
</body>
</html>
"""


@app.route("/", methods=["GET", "POST"])
def home():
    tekst = ""
    gespiegeld = None

    if request.method == "POST":
        tekst = request.form.get("tekst", "")
        gespiegeld = tekst[::-1]

    return render_template_string(HTML, tekst=tekst, gespiegeld=gespiegeld)


if __name__ == "__main__":
    app.run(host="0.0.0.0", debug=True)
