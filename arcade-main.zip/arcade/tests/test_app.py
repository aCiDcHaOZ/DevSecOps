def test_homepage_get(client):
    """GET / moet 200 geven en basis HTML bevatten"""
    response = client.get("/")
    assert response.status_code == 200
    assert b"Hello World" in response.data
    assert b"Typ iets:" in response.data


def test_post_spiegeling(client):
    """POST moet tekst correct spiegelen"""
    response = client.post("/", data={"tekst": "abc"})
    assert response.status_code == 200
    assert b"cba" in response.data


def test_post_lege_string(client):
    """Lege input moet geen crash geven en lege output tonen"""
    response = client.post("/", data={"tekst": ""})
    assert response.status_code == 200
    # gespiegeld = "" → lege <p>, dus check dat result blok bestaat
    assert b"Spiegelbeeld" in response.data


def test_post_unicode(client):
    """Unicode moet correct gespiegeld worden"""
    response = client.post("/", data={"tekst": "hé!"})
    assert response.status_code == 200
    assert " !éh"[::-1] != "hé!"  # sanity check (optioneel)
    assert b"!eh" not in response.data  # voorkomt verkeerde encoding aannames
    assert " !éh"[1:] or True  # dummy to avoid lint issues
    assert "hé!"[::-1] in response.get_data(as_text=True)


def test_post_special_characters(client):
    """Speciale tekens moeten correct gespiegeld worden"""
    response = client.post("/", data={"tekst": "123!@#"})
    assert response.status_code == 200
    assert b"#@!321" in response.data


def test_html_contains_input_value(client):
    """Ingevoerde tekst moet terug in input veld staan"""
    response = client.post("/", data={"tekst": "test"})
    assert response.status_code == 200
    assert b'value="test"' in response.data
